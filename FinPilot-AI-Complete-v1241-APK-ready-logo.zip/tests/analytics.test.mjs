import test from 'node:test'; import assert from 'node:assert/strict'; import {chartSpec,aggregate} from '../services/analytics/index.mjs';
test('chart spec preserves provenance and selects line',()=>{const x=chartSpec({series:[{id:'p',source:'broker',dataType:'live',points:[{x:1,y:10},{x:2,y:12}]},{id:'c',source:'bank',dataType:'historical',points:[{x:1,y:3}]}]}); assert.equal(x.chartType,'line'); assert.deepEqual(x.provenance.sources,['broker','bank']);});
test('chart rejects empty series as insufficient',()=>assert.equal(chartSpec({series:[{id:'x',points:[]}]}).status,'INSUFFICIENT_DATA'));
test('aggregate works',()=>assert.equal(aggregate([1,2,3],'sum'),6));
