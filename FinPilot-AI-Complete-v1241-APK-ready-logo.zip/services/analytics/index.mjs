export const DATA_TYPES = new Set(['live','historical','estimate','simulation']);
export function normalizeSeries(input={}) {
  const points = Array.isArray(input.points) ? input.points : [];
  const clean = points.map((p,i)=>({x:p?.x ?? i, y:Number(p?.y)})).filter(p=>Number.isFinite(p.y));
  return {id:String(input.id||'series'), label:String(input.label||input.id||'Series'), unit:String(input.unit||''), points:clean,
    provenance:{source:String(input.source||'unknown'), retrievedAt:String(input.retrievedAt||new Date().toISOString()), dataType:DATA_TYPES.has(input.dataType)?input.dataType:'historical'}};
}
export function chooseChartType(series=[], hint='auto') {
  if (['line','bar','area','scatter','pie'].includes(hint)) return hint;
  const n=series.length;
  if(n===1 && series[0]?.points?.length<=12) return 'bar';
  if(n>1) return 'line';
  return 'line';
}
export function chartSpec(input={}) {
  const series=(Array.isArray(input.series)?input.series:[]).map(normalizeSeries);
  return {title:String(input.title||'FinPilot Analytics'), chartType:chooseChartType(series,input.chartType), series,
    provenance:{sources:[...new Set(series.map(s=>s.provenance.source))],dataTypes:[...new Set(series.map(s=>s.provenance.dataType))],generatedAt:new Date().toISOString()},
    status:series.some(s=>s.points.length===0)?'INSUFFICIENT_DATA':'READY'};
}
export function aggregate(points=[], mode='sum') {
  const vals=points.map(Number).filter(Number.isFinite); if(!vals.length)return null;
  if(mode==='avg')return vals.reduce((a,b)=>a+b,0)/vals.length;
  if(mode==='min')return Math.min(...vals); if(mode==='max')return Math.max(...vals);
  return vals.reduce((a,b)=>a+b,0);
}
